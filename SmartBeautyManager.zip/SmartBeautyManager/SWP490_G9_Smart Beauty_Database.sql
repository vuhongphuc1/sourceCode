-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: sbeauty
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bed_branch_mapping`
--

DROP TABLE IF EXISTS `bed_branch_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bed_branch_mapping` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `id_branch` bigint NOT NULL,
  `id_spa_bed` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bed_branch_mapping`
--

LOCK TABLES `bed_branch_mapping` WRITE;
/*!40000 ALTER TABLE `bed_branch_mapping` DISABLE KEYS */;
INSERT INTO `bed_branch_mapping` VALUES (1,1,1),(2,1,2),(3,1,3),(4,1,4),(5,1,5);
/*!40000 ALTER TABLE `bed_branch_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bed_slot_mapping`
--

DROP TABLE IF EXISTS `bed_slot_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bed_slot_mapping` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `id_slot` bigint NOT NULL,
  `id_spa_bed` bigint NOT NULL,
  `id_schedule` bigint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bed_slot_mapping`
--

LOCK TABLES `bed_slot_mapping` WRITE;
/*!40000 ALTER TABLE `bed_slot_mapping` DISABLE KEYS */;
INSERT INTO `bed_slot_mapping` VALUES (22,'2022-11-28T17:00:00.000Z',1,1,22),(25,'2022-11-28T17:00:00.000Z',3,3,25),(26,'2022-11-28T17:00:00.000Z',4,1,26),(27,'2022-11-29T17:00:00.000Z',1,1,27),(28,'2022-11-29T17:00:00.000Z',2,1,28),(29,'2022-11-27T17:00:00.000Z',1,1,29),(32,'2022-11-28T17:00:00.000Z',2,1,32),(33,'2022-11-28T17:00:00.000Z',1,2,33),(34,'2022-11-29T17:00:00.000Z',1,3,34),(35,'2022-11-29T17:00:00.000Z',3,1,35),(36,'2022-11-29T17:00:00.000Z',4,1,36),(37,'2022-11-30T00:00:00.000Z',5,1,37),(38,'2022-12-01T00:00:00.000Z',1,1,38),(39,'2022-12-01T00:00:00.000Z',2,1,39),(40,'2022-12-02T00:00:00.000Z',2,1,40),(41,'2022-12-02T00:00:00.000Z',3,1,41),(42,'2022-12-01T00:00:00.000Z',4,1,42),(43,'2022-12-02T00:00:00.000Z',3,3,43),(45,'2022-12-02T00:00:00.000Z',4,3,45),(46,'2022-12-13T00:00:00.000Z',2,1,46),(47,'2022-12-13T00:00:00.000Z',4,3,47),(48,'2022-12-13T00:00:00.000Z',3,2,48),(49,'2022-12-13T00:00:00.000Z',3,3,49),(50,'2022-12-13T00:00:00.000Z',1,2,50),(51,'2022-12-13T00:00:00.000Z',2,3,51);
/*!40000 ALTER TABLE `bed_slot_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bill`
--

DROP TABLE IF EXISTS `bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bill` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `create_date` varchar(255) DEFAULT NULL,
  `price_after_tax` double DEFAULT NULL,
  `price_before_tax` double DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill`
--

LOCK TABLES `bill` WRITE;
/*!40000 ALTER TABLE `bill` DISABLE KEYS */;
INSERT INTO `bill` VALUES (20,NULL,'2022-11-28T11:03:47Z',1080000,1000000,'2'),(21,NULL,'2022-11-28T11:16:59Z',1080000,1000000,'0'),(22,NULL,'2022-11-28T13:31:25Z',1080000,1000000,'2'),(23,NULL,'2022-11-28T14:07:06Z',1080000,1000000,'1'),(24,NULL,'2022-11-28T15:01:25Z',1080000,1000000,'2'),(25,NULL,'2022-11-29T03:18:37Z',1080000,1000000,'0'),(26,NULL,'2022-11-29T04:01:36Z',1080000,1000000,'2'),(27,NULL,'2022-11-29T04:11:08Z',1080000,1000000,'2'),(28,NULL,'2022-11-29T17:25:19Z',1080000,1000000,'2'),(29,NULL,'2022-11-30T16:47:43Z',2268000,2100000,'2'),(30,NULL,'2022-11-30T17:43:26Z',2160000,2000000,'2'),(31,NULL,'2022-12-13T09:07:28Z',1080000,1000000,'2'),(32,NULL,'2022-12-13T09:38:02Z',2116800,2000000,'2'),(33,NULL,'2022-12-13T10:30:17Z',1944000,1800000,'2');
/*!40000 ALTER TABLE `bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bill_bill_detail_mapping`
--

DROP TABLE IF EXISTS `bill_bill_detail_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bill_bill_detail_mapping` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `bill_detail_id` bigint NOT NULL,
  `bill_id` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill_bill_detail_mapping`
--

LOCK TABLES `bill_bill_detail_mapping` WRITE;
/*!40000 ALTER TABLE `bill_bill_detail_mapping` DISABLE KEYS */;
INSERT INTO `bill_bill_detail_mapping` VALUES (30,30,20),(31,31,21),(32,32,22),(33,33,23),(34,34,24),(35,35,25),(36,36,26),(37,37,27),(38,38,28),(39,39,29),(40,40,29),(41,41,30),(42,42,31),(43,43,32),(44,44,33);
/*!40000 ALTER TABLE `bill_bill_detail_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bill_branch_mapping`
--

DROP TABLE IF EXISTS `bill_branch_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bill_branch_mapping` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `bill_id` bigint NOT NULL,
  `branch_id` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill_branch_mapping`
--

LOCK TABLES `bill_branch_mapping` WRITE;
/*!40000 ALTER TABLE `bill_branch_mapping` DISABLE KEYS */;
INSERT INTO `bill_branch_mapping` VALUES (19,20,1),(20,21,1),(21,22,1),(22,23,1),(23,24,1),(24,25,1),(25,26,1),(26,27,1),(27,28,1),(28,29,1),(29,30,1),(30,31,1),(31,32,1),(32,33,1);
/*!40000 ALTER TABLE `bill_branch_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bill_course_history`
--

DROP TABLE IF EXISTS `bill_course_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bill_course_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `course_id` bigint DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `discount_end` varchar(255) DEFAULT NULL,
  `discount_percent` double DEFAULT NULL,
  `discount_start` varchar(255) DEFAULT NULL,
  `duration` int DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `schedule_id` bigint DEFAULT NULL,
  `time_of_use` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill_course_history`
--

LOCK TABLES `bill_course_history` WRITE;
/*!40000 ALTER TABLE `bill_course_history` DISABLE KEYS */;
INSERT INTO `bill_course_history` VALUES (1,'code',1,NULL,'abc','2022-11-28T17:00:00.000Z',5,'2022-11-26T17:00:00.000Z',90,'pikachu2.jpg','Liệu trình nặn mụn',2000000,34,5),(2,'code',1,NULL,'abc','2022-11-28T17:00:00.000Z',5,'2022-11-26T17:00:00.000Z',90,'pikachu2.jpg','Liệu trình nặn mụn',2000000,35,5),(3,'code',1,NULL,'abc','2022-11-28T17:00:00.000Z',5,'2022-11-26T17:00:00.000Z',90,'pikachu2.jpg','Liệu trình nặn mụn',2000000,38,5),(4,'code',1,NULL,'abc','2022-11-28T17:00:00.000Z',5,'2022-11-26T17:00:00.000Z',90,'pikachu2.jpg','Liệu trình nặn mụn',2000000,42,5),(5,'code',2,NULL,'liêu trình trị rỗ',NULL,NULL,NULL,90,NULL,'Liệu trình trị rỗ ',5000000,44,5),(6,'code',2,NULL,'liêu trình trị rỗ',NULL,NULL,NULL,90,NULL,'Liệu trình trị rỗ ',5000000,45,5),(7,'code',1,NULL,'abcds','2022-12-15T17:00:00.000Z',32,'2022-12-14T17:00:00.000Z',90,'sua_rua_mat_e100_con_bo.jpg','Liệu trình nặn mụn',1000000,46,5),(8,'code',1,NULL,'abcds','2022-12-15T17:00:00.000Z',32,'2022-12-14T17:00:00.000Z',90,'sua_rua_mat_e100_con_bo.jpg','Liệu trình nặn mụn',1000000,51,5);
/*!40000 ALTER TABLE `bill_course_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bill_customer_mapping`
--

DROP TABLE IF EXISTS `bill_customer_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bill_customer_mapping` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `bill_id` bigint NOT NULL,
  `customer_id` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill_customer_mapping`
--

LOCK TABLES `bill_customer_mapping` WRITE;
/*!40000 ALTER TABLE `bill_customer_mapping` DISABLE KEYS */;
INSERT INTO `bill_customer_mapping` VALUES (17,20,1),(18,21,2),(19,22,2),(20,23,1),(21,24,1),(22,25,2),(23,26,1),(24,27,2),(25,28,1),(26,29,1),(27,30,2),(28,31,10),(29,32,13),(30,33,20);
/*!40000 ALTER TABLE `bill_customer_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bill_detail`
--

DROP TABLE IF EXISTS `bill_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bill_detail` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `course_id` bigint DEFAULT NULL,
  `product_id` bigint DEFAULT NULL,
  `quantity` bigint DEFAULT NULL,
  `service_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill_detail`
--

LOCK TABLES `bill_detail` WRITE;
/*!40000 ALTER TABLE `bill_detail` DISABLE KEYS */;
INSERT INTO `bill_detail` VALUES (30,NULL,NULL,1,22),(31,NULL,NULL,1,24),(32,NULL,NULL,1,27),(33,NULL,NULL,1,29),(34,NULL,NULL,1,25),(35,NULL,NULL,1,23),(36,NULL,NULL,1,26),(37,NULL,NULL,1,32),(38,NULL,NULL,1,35),(39,NULL,1,1,NULL),(40,3,NULL,1,NULL),(41,4,NULL,1,NULL),(42,7,NULL,1,NULL),(43,NULL,1,1,NULL),(44,NULL,2,1,NULL);
/*!40000 ALTER TABLE `bill_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bill_product_history`
--

DROP TABLE IF EXISTS `bill_product_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bill_product_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `bill_detail_id` bigint DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `discount_end` varchar(255) DEFAULT NULL,
  `discount_percent` double DEFAULT NULL,
  `discount_start` varchar(255) DEFAULT NULL,
  `dose` int DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `product_id` bigint DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill_product_history`
--

LOCK TABLES `bill_product_history` WRITE;
/*!40000 ALTER TABLE `bill_product_history` DISABLE KEYS */;
INSERT INTO `bill_product_history` VALUES (1,1,'2022-11-27T03:06:11.456Z','Sữa rửa mặt','2022-11-27T17:00:00.000Z',10,'2022-11-26T17:00:00.000Z',100,'pikachu1.jpg','Sữa rửa mặt DAF',100000,1,'ml'),(2,3,'2022-11-28T17:00:00.000Z','Sữa rửa mặt','2022-11-27T17:00:00.000Z',10,'2022-11-26T17:00:00.000Z',100,'pikachu1.jpg','Sữa rửa mặt DAF',100000,1,'ml'),(3,5,'2022-11-28T17:00:00.000Z','Sữa rửa mặt','2022-11-27T17:00:00.000Z',10,'2022-11-26T17:00:00.000Z',100,'pikachu1.jpg','Sữa rửa mặt DAF',100000,1,'ml'),(4,6,'2022-11-28T17:00:00.000Z','Sữa rửa mặt','2022-11-27T17:00:00.000Z',10,'2022-11-26T17:00:00.000Z',100,'pikachu1.jpg','Sữa rửa mặt DAF',100000,1,'ml'),(5,7,'2022-11-28T17:00:00.000Z','Sữa rửa mặt','2022-11-27T17:00:00.000Z',10,'2022-11-26T17:00:00.000Z',100,'pikachu1.jpg','Sữa rửa mặt DAF',100000,1,'ml'),(6,8,'2022-11-28T17:00:00.000Z','Sữa rửa mặt','2022-11-27T17:00:00.000Z',10,'2022-11-26T17:00:00.000Z',100,'pikachu1.jpg','Sữa rửa mặt DAF',100000,1,'ml'),(7,9,'2022-11-28T17:00:00.000Z','Sữa rửa mặt','2022-11-27T17:00:00.000Z',10,'2022-11-26T17:00:00.000Z',100,'pikachu1.jpg','Sữa rửa mặt DAF',100000,1,'ml'),(8,11,'2022-11-28T17:00:00.000Z','Sữa rửa mặt','2022-11-27T17:00:00.000Z',10,'2022-11-26T17:00:00.000Z',100,'pikachu1.jpg','Sữa rửa mặt DAF',100000,1,'ml'),(9,13,'2022-11-28T17:00:00.000Z','Sữa rửa mặt','2022-11-27T17:00:00.000Z',10,'2022-11-26T17:00:00.000Z',100,'pikachu1.jpg','Sữa rửa mặt DAF',100000,1,'ml'),(10,16,NULL,'Sữa rửa mặt','2022-11-27T17:00:00.000Z',10,'2022-11-26T17:00:00.000Z',100,'pikachu1.jpg','Sữa rửa mặt DAF',100000,1,'ml'),(11,17,NULL,'Sữa rửa mặt','2022-11-27T17:00:00.000Z',10,'2022-11-26T17:00:00.000Z',100,'pikachu1.jpg','Sữa rửa mặt DAF',100000,1,'ml'),(12,18,'2022-11-28T17:00:00.000Z','Sữa rửa mặt','2022-11-27T17:00:00.000Z',10,'2022-11-26T17:00:00.000Z',100,'pikachu1.jpg','Sữa rửa mặt DAF',100000,1,'ml'),(13,20,NULL,'Sữa rửa mặt','2022-11-27T17:00:00.000Z',10,'2022-11-26T17:00:00.000Z',100,'pikachu1.jpg','Sữa rửa mặt DAF',100000,1,'ml'),(14,21,'2022-11-30T17:00:00.000Z','Sữa rửa mặt','2022-11-27T17:00:00.000Z',10,'2022-11-26T17:00:00.000Z',100,'pikachu1.jpg','Sữa rửa mặt DAF',100000,1,'ml'),(15,24,NULL,'Sữa rửa mặt','2022-11-27T17:00:00.000Z',10,'2022-11-26T17:00:00.000Z',100,'pikachu1.jpg','Sữa rửa mặt DAF',100000,1,'ml'),(16,26,NULL,'Sữa rửa mặt','2022-11-27T17:00:00.000Z',10,'2022-11-26T17:00:00.000Z',100,'pikachu1.jpg','Sữa rửa mặt DAF',100000,1,'ml'),(17,39,NULL,'Sữa rửa mặt','2022-11-27T17:00:00.000Z',10,'2022-11-26T17:00:00.000Z',100,'pikachu1.jpg','Sữa rửa mặt DAF',100000,1,'ml'),(18,43,NULL,'Làm mềm, làm mát da, se khít lỗ chân lông. giữ ẩm, tái cân bằng lipid bảo vệ da không gây cảm giác bóng nhờn ','2022-12-14T17:00:00.000Z',2,'2022-12-12T17:00:00.000Z',100,'sua_rua_mat_e100_con_bo.jpg','PURE COMFORT MASK',2000000,1,'ml'),(19,44,NULL,'Mạng lại làn da mượt mà, không nết nhăn','2022-12-19T17:00:00.000Z',0,'2022-12-14T17:00:00.000Z',100,'sua_rua_mat_e100_con_bo.jpg','Tinh chất ức chế nết nhăn',1800000,2,'ml');
/*!40000 ALTER TABLE `bill_product_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bill_service_history`
--

DROP TABLE IF EXISTS `bill_service_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bill_service_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `discount_end` varchar(255) DEFAULT NULL,
  `discount_percent` double DEFAULT NULL,
  `discount_start` varchar(255) DEFAULT NULL,
  `duration` bigint DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `schedule_id` bigint DEFAULT NULL,
  `service_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill_service_history`
--

LOCK TABLES `bill_service_history` WRITE;
/*!40000 ALTER TABLE `bill_service_history` DISABLE KEYS */;
INSERT INTO `bill_service_history` VALUES (1,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,1,1),(2,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,2,1),(3,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,3,1),(4,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,4,1),(5,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,5,1),(6,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,6,1),(7,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,7,1),(8,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,8,1),(9,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,9,1),(10,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,10,1),(11,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,11,1),(12,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,12,1),(13,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,13,1),(14,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,14,1),(15,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,15,1),(16,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,16,1),(17,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,17,1),(18,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,18,1),(19,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,19,1),(20,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,20,1),(21,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,21,1),(22,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,22,1),(23,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,23,1),(24,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,24,1),(25,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,25,1),(26,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,26,1),(27,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,27,1),(28,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,28,1),(29,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,29,1),(30,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,30,1),(31,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,31,1),(32,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,32,1),(33,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,33,1),(34,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,36,1),(35,'nặn mụn',NULL,NULL,NULL,90,'pikachu1.jpg','Nặn mụn',1000000,37,1);
/*!40000 ALTER TABLE `bill_service_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bill_user_mapping`
--

DROP TABLE IF EXISTS `bill_user_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bill_user_mapping` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `bill_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill_user_mapping`
--

LOCK TABLES `bill_user_mapping` WRITE;
/*!40000 ALTER TABLE `bill_user_mapping` DISABLE KEYS */;
INSERT INTO `bill_user_mapping` VALUES (19,20,4),(20,21,4),(21,22,4),(22,23,4),(23,24,4),(24,25,4),(25,26,4),(26,27,4),(27,28,4),(28,29,4),(29,30,4),(30,31,4),(31,32,4),(32,33,4);
/*!40000 ALTER TABLE `bill_user_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branch`
--

DROP TABLE IF EXISTS `branch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `branch` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branch`
--

LOCK TABLES `branch` WRITE;
/*!40000 ALTER TABLE `branch` DISABLE KEYS */;
INSERT INTO `branch` VALUES (1,'Ha Noi','hnbranch@gmail.com','branch_1sua_rua_mat_e100_con_bo.jpg','HN Branch','0913823827'),(2,'Hai Phong','haiphongbranch@gmail.com',NULL,'Hai Phong Branch','0193827473'),(3,'Hà Nội','hannhibeauty@gmail.com',NULL,'Hân Nhi Beauty','0343242423'),(4,'Hà Nội','hannhibeauty1@gmail.com',NULL,'Hân Nhi Beauty13','3432432223'),(5,'Hà Nộii','hannhibeauty11@gmail.com',NULL,'Hân Nhi Beauty1','0121223123'),(6,'Hà Nội','hannhibeauty2@gmail.com',NULL,'Hân Nhi Beauty2','0232313231'),(7,'Hà Nội','hannhibeauty3@gmail.com',NULL,'Hân Nhi Beauty3','0132312323'),(8,'Hà Nội','hannhibeauty4@gmail.com',NULL,'Hân Nhi Beauty4','0143545353'),(9,'Hà Nội','hannhibeauty6@gmail.com',NULL,'Hân Nhi Beauty5','0234424424'),(10,'Hà Nội','hannhibeauty@gmail.co',NULL,'Hân Nhi Beauty6','0233424342'),(11,'Hà Nội','hannhibeauty8@gmail.com',NULL,'Hân Nhi Beauty8','0456546465'),(12,'Hà Nội','hannhibeauty14@gmail.com',NULL,'Hân Nhi Beauty9','0456546546'),(13,'abcv','hannhibeauty10@gmail.com',NULL,'beauty','0345433534');
/*!40000 ALTER TABLE `branch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branch_user`
--

DROP TABLE IF EXISTS `branch_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `branch_user` (
  `branch_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`branch_id`,`user_id`),
  KEY `FKmlgnse0ibk36jgp4yk0dd5ts7` (`user_id`),
  CONSTRAINT `FKg973x7lagvfhn5vxdb2w9h8l7` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`id`),
  CONSTRAINT `FKmlgnse0ibk36jgp4yk0dd5ts7` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branch_user`
--

LOCK TABLES `branch_user` WRITE;
/*!40000 ALTER TABLE `branch_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `branch_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `discount_end` varchar(255) DEFAULT NULL,
  `discount_percent` double DEFAULT NULL,
  `discount_start` varchar(255) DEFAULT NULL,
  `duration` int NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `time_of_use` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES (1,'code','abcds','2022-12-20T17:00:00.000Z',2,'2022-12-19T17:00:00.000Z',90,'sua_rua_mat_e100_con_bo.jpg','Liệu trình nặn mụn',1000000,5),(2,'code','liêu trình trị rỗ',NULL,NULL,NULL,90,'sua_rua_mat_e100_con_bo.jpg','Liệu trình trị rỗ ',0,5),(3,'code','Dịch vụ chăm sóc da mặt sẽ có các gói từ cơ bản đến chuyên sâu tùy vào tình trạng da mặt của từng khách, cung cấp thêm dưỡng chất thấm sâu vào da, nuôi dưỡng làn da sáng mịn.',NULL,NULL,NULL,60,'sua_rua_mat_e100_con_bo.jpg','Liệu Trình Chăm Sóc Da Mặt, Thư Giãn',1000000,4),(4,'code','Liệu trình giúp những chị em nào gặp phải vấn đề tóc rụng, tóc rối. Liệu trình đi sâu vào cải thiện độ tươi trẻ của tóc, cung cấp thêm các dưỡng chất giúp phục hồi tóc hư tổn.',NULL,NULL,NULL,30,'sua_rua_mat_e100_con_bo.jpg','Giảm Rụng Tóc Cấp Tốc',10000,4),(5,'code','Điều trị mụn là phương pháp hiệu quả nhất nhằm làm sạch mụn, se khít lỗ chân lông và giảm vết sẹo thâm do mụn để lại.',NULL,NULL,NULL,60,'sua_rua_mat_e100_con_bo.jpg','Liệu trình điều trị mụn, sẹo',3000000,7),(6,'code','Dịch vụ trị thâm, nám, tàng nhang giúp lấy lại sự tươi trẻ cho làn da, đây là một trong những dịch vụ spa thu hút khách hàng nhất hiện nay bởi nhu cầu là rất lớn.',NULL,NULL,NULL,60,'sua_rua_mat_e100_con_bo.jpg','Liệu trình trị thâm, nám, tàn nhang',5000000,10),(7,'code','Thông thường một liệu trình dịch vụ trẻ hóa da sẽ bao gồm cả trị sẹo, vết thâm, nám, tàng nhang. Hiệu quả dịch vụ sẽ nhanh chóng và kéo dài tới vài năm.',NULL,NULL,NULL,90,'sua_rua_mat_e100_con_bo.jpg','Liệu trình trẻ hóa da',4000000,10),(8,'code','Tăng cân, béo phì là vấn đề mà rất nhiều chị em lo lắng, việc chăm lo cho vóc dáng dường như đã trở thành nhu cầu thiết yếu của con người trong cuộc sống hiện đại.',NULL,NULL,NULL,120,'sua_rua_mat_e100_con_bo.jpg','Liệu trình giảm béo',10000000,15),(9,'code','Wax lông thực sự là một dịch vụ Spa tiềm năng, nó không chỉ giúp spa kiếm đông khách vào mùa hè mà vẫn tiếp tục thu hút khách trong mùa xuân, thu, đông và trong tương lai.',NULL,NULL,NULL,30,NULL,'Dịch vụ triệt lông vĩnh viễn',0,7),(10,'code','Không giống với phương Tây, phụ nữ Việt Nam luôn mong muốn mình có được một làn da trắng hồng, mịn màng',NULL,NULL,NULL,60,NULL,'Dịch vụ tắm trắng',2000000,5),(11,'code','Đặc biệt',NULL,NULL,NULL,60,'sua_rua_mat_e100_con_bo.jpg','Gói dịch vụ đặc biệt',10000000,15);
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_service_mapping`
--

DROP TABLE IF EXISTS `course_service_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_service_mapping` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `course_id` bigint NOT NULL,
  `service_id` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_service_mapping`
--

LOCK TABLES `course_service_mapping` WRITE;
/*!40000 ALTER TABLE `course_service_mapping` DISABLE KEYS */;
INSERT INTO `course_service_mapping` VALUES (2,2,1),(3,2,2),(4,3,3),(7,4,3),(8,5,1),(9,5,6),(12,6,3),(13,7,3),(14,8,6),(15,9,11),(16,10,6),(17,11,3),(18,11,5),(19,11,2);
/*!40000 ALTER TABLE `course_service_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `date_of_birth` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'An Khánh, Hoài Đức, Hà Nội','1999-02-03T17:00:00.000Z','hoangtrung@gmail.com','male','Nguyễn Hoàng Trung','0939284374'),(2,'Xã An Khánh, Huyện Hoài Đức, Hà Nội','2001-05-23T17:00:00.000Z','thanhmai@gmail.com','female','Nguyễn Thanh Mai','0937837456'),(3,'Xã An Khánh, Huyện Hoài Đức, Hà Nội','2001-05-23T17:00:00.000Z','thuylinh@gmail.com','female','Nguyễn Thùy Linh','0912792334'),(4,'Xã An Khánh, Huyện Hoài Đức, Hà Nội','2001-05-23T17:00:00.000Z','thuytrang@gmail.com','female','Nguyễn Thùy Trang','0912792335'),(5,'Xã An Khánh, Huyện Hoài Đức, Hà Nội','2001-05-23T17:00:00.000Z','minhnghi@gmail.com','female','Trần Minh Nghi','0912792336'),(6,'Xã An Khánh, Huyện Hoài Đức, Hà Nội','2001-05-23T17:00:00.000Z','thaotrang@gmail.com','female','Trần Thảo Trang','0912792337'),(7,'Xã An Khánh, Huyện Hoài Đức, Hà Nội','2001-05-23T17:00:00.000Z','minhha@gmail.com','female','Trần Minh Hà','0912792338'),(8,'Xã An Khánh, Huyện Hoài Đức, Hà Nội','2001-05-23T17:00:00.000Z','thuyquynh@gmail.com','female','Đổng Thúy Quỳnh','0912792339'),(9,'Xã An Khánh, Huyện Hoài Đức, Hà Nội','2001-05-23T17:00:00.000Z','hoaithuong@gmail.com','female','Nguyễn Hoài Thương','0936791999'),(10,'Cầu Giấy, Hà Nội','2000-10-17T17:00:00.000Z','phucvh@gmail.com','male','Vũ Hồng Phúc','0324324343'),(11,'Quốc Oai, Hà Hội','2000-05-07T17:00:00.000Z','manhpd@gmail.com','male','Phùng Đức Mạnh','0342342343'),(12,'Đống Đa, Hà Nội','1997-05-06T17:00:00.000Z','hoangtn@gmail.com','male','Trần Nhật Hoàng','0324343434'),(13,'Ba Đình, Hà Nội','2000-08-30T17:00:00.000Z','lamvh@gmail.com','male','Vũ Hải Lâm','0321564645'),(14,'Hà Nội','1999-05-04T17:00:00.000Z','anhltn@gmail.com','female','Lê Thị Ngọc Ánh','0327563233'),(15,'Hà Nội','2002-02-13T17:00:00.000Z','phuongvtm@gmail.com','female','Vũ Thị Minh Phương','0562345544'),(16,'Hà Nội','1999-04-12T17:00:00.000Z','thuongvt@gmail.com','female','Vũ Thị Thương','0351254553'),(17,'Hà Nội','1993-04-07T17:00:00.000Z','tamdt@gmail.com','female','Dương Thị Tâm','0546897234'),(18,'Hà Nội','1997-08-13T17:00:00.000Z','thuynt@gmail.com','female','Ngô Thị Thủy','0342342342'),(19,'Hà Nội','2003-04-08T17:00:00.000Z','ngocnt@gmail.com','female','Nguyễn Thị Ngọc','0354354543'),(20,'Cầu Giấy, Hà Nội','2000-02-08T17:00:00.000Z','phucvh12@gmail.com','male','Vũ Hồng Phúc','0434242342');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_branch_mapping`
--

DROP TABLE IF EXISTS `customer_branch_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_branch_mapping` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `id_branch` bigint NOT NULL,
  `id_customer` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_branch_mapping`
--

LOCK TABLES `customer_branch_mapping` WRITE;
/*!40000 ALTER TABLE `customer_branch_mapping` DISABLE KEYS */;
INSERT INTO `customer_branch_mapping` VALUES (1,1,1),(2,1,2),(3,1,10),(4,1,11),(5,1,12),(6,1,13),(7,1,14),(8,1,15),(9,1,16),(10,1,17),(11,1,18),(12,1,19),(13,11,20);
/*!40000 ALTER TABLE `customer_branch_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_course_mapping`
--

DROP TABLE IF EXISTS `customer_course_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_course_mapping` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `bill_detail_id` bigint DEFAULT NULL,
  `count` int DEFAULT NULL,
  `course_id` bigint DEFAULT NULL,
  `customer_id` bigint DEFAULT NULL,
  `end_date` varchar(255) DEFAULT NULL,
  `service_id` bigint DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_course_mapping`
--

LOCK TABLES `customer_course_mapping` WRITE;
/*!40000 ALTER TABLE `customer_course_mapping` DISABLE KEYS */;
INSERT INTO `customer_course_mapping` VALUES (13,30,NULL,NULL,1,NULL,22,'3'),(14,31,NULL,NULL,2,NULL,24,'3'),(15,32,NULL,NULL,2,NULL,27,'3'),(16,33,NULL,NULL,1,NULL,29,'2'),(17,34,NULL,NULL,1,NULL,25,'3'),(18,35,NULL,NULL,2,NULL,23,'1'),(19,36,NULL,NULL,1,NULL,26,'3'),(20,37,NULL,NULL,2,NULL,32,'3'),(21,38,NULL,NULL,1,NULL,35,'3'),(22,40,4,3,1,'2023-02-28T17:00:00.000Z',NULL,'2'),(23,41,1,4,2,'2023-02-28T17:00:00.000Z',NULL,'2'),(24,42,5,7,10,'2023-03-13T17:00:00.000Z',NULL,'3');
/*!40000 ALTER TABLE `customer_course_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `discount_end` varchar(255) DEFAULT NULL,
  `discount_percent` double DEFAULT NULL,
  `discount_start` varchar(255) DEFAULT NULL,
  `dose` int DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,'Làm mềm, làm mát da, se khít lỗ chân lông. giữ ẩm, tái cân bằng lipid bảo vệ da không gây cảm giác bóng nhờn ','2022-11-27T17:00:00.000Z',10,'2022-11-26T17:00:00.000Z',100,'pikachu1.jpg','PURE COMFORT MASK',1100000,'ml'),(2,'Mạng lại làn da mượt mà, không nết nhăn',NULL,0,NULL,100,'pikachu1.jpg','Tinh chất ức chế nết nhăn',1800000,'ml'),(3,'Mặt nạ nâng cơ dành cho mặt và cổ, với tác dụng loại bỏ nếp nhăn. Sản phẩm dạng miếng mang hiệu quả tức thì và vượt trội.',NULL,0,NULL,500,NULL,'Mặt nạ nâng cơ LIFT ACTION MASK',160000,'ml'),(4,'Sản phẩm tẩy trang kiêm rửa mặt chứa các thành phần đặc biệt giúp loại bỏ lớp trang điểm, dầu thừa và bụi bẩn ra khỏi da',NULL,0,NULL,1000,'tẩy trang.jpg','TẨY TRANG EMULSI VỚI CHIẾT XUẤT DƯỠNG DỪA',1380000,'ml'),(5,'giúp loại bỏ dầu thừa và lớp trang điểm khỏi da. Dung tích lớn phù hợp cho các liệu trình chăm sóc da chuyên nghiệp tại Spa. Mỹ phẩm cao cấp chính hãng số 1 Tây Ban Nha và châu Âu',NULL,0,NULL,120,'ruamatduachuot.jpg','Sửa rửa mặt tinh chất dưa chuột',200000,'ml'),(6,'Với thành phần chính bao gồm nhiều loại thảo dược cao cấp như Phấn hoa, hồng sâm, tam thất, cúc la mã, đào hoa, nhau thai cừu, ngọc trai, linh chi, nghệ đen, mật ong nguyên tổ.',NULL,0,NULL,150,'thienhuong.jpg','Serum Thảo Mộc Thiên Hương',400000,'g'),(7,'giữ ẩm bảo vệ da trẻ hóa da và ngăn ngừa sắc tố melanin hình thànhbr Eaoron Black Caviar cream đáp ứng hầu hết các nhu cầu của phái đẹp vừa làm trắng dưỡng ẩm vừa trẻ hóa se khít lỗ chân lông.','2022-12-19T17:00:00.000Z',2,'2022-12-11T17:00:00.000Z',300,'trùncaden.jpg','Kem Trứng Cá Đen',620000,'g'),(8,'Mặt nạ giúp làm trắng, cung cấp độ ẩm cho da và trên hết cực kỳ an toàn do các thành phần hoàn toàn làm từ thiên nhiên. ',NULL,0,NULL,1,'matnangoctrai.jpg','Mặt Nạ  Ngọc Trai Dưỡng Trắng Da',80000,'cái'),(9,'Thành phần chính là BỒ KẾT và HOA HỒNG, cùng với các loại hoa lá thảo dược dưỡng tóc tự nhiên khác được truyền lại từ thời xưa giúp Làm sạch tóc và da đầu.',NULL,0,NULL,500,'nuoc goi dau.jpg','Nước gội đầu hoa hồng Karose Shine',160000,'ml'),(10,'- Làm sạch lớp trang điểm, bụi bẩn, bã nhờn.\r\n- Làm sạch sâu, làm dịu da, ngừa mụn','2022-12-29T17:00:00.000Z',26,'2022-12-14T17:00:00.000Z',1,'combosanpham.jpg','COMBO LÀM SẠCH SÂU-BẢO VỆ DA NÁM-TÀN NHANG',420000,'bộ'),(12,'',NULL,NULL,NULL,150,'product_12sua_rua_mat_e100_con_bo.jpg','Kem Trắng Da',150000,'ml');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_supplier_mapping`
--

DROP TABLE IF EXISTS `product_supplier_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_supplier_mapping` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `id_product` bigint NOT NULL,
  `id_supplier` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_supplier_mapping`
--

LOCK TABLES `product_supplier_mapping` WRITE;
/*!40000 ALTER TABLE `product_supplier_mapping` DISABLE KEYS */;
INSERT INTO `product_supplier_mapping` VALUES (1,1,1),(2,2,1),(3,3,1),(4,4,1),(5,5,3),(6,6,4),(7,7,2),(8,8,5),(9,9,1),(10,10,4),(11,11,1),(12,11,2),(13,12,11);
/*!40000 ALTER TABLE `product_supplier_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'admin'),(2,'manager'),(3,'sale_staff'),(4,'technical_staff');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `bed_id` bigint DEFAULT NULL,
  `course_history_id` bigint DEFAULT NULL,
  `course_id` bigint DEFAULT NULL,
  `customer_id` bigint DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `sale_staff_id` bigint DEFAULT NULL,
  `service_id` bigint DEFAULT NULL,
  `slot_id` bigint DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `technical_staff_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
INSERT INTO `schedule` VALUES (22,1,NULL,NULL,1,'2022-11-28T17:00:00.000Z','',4,22,1,'0',6),(23,2,NULL,NULL,2,'2022-11-28T17:00:00.000Z','',4,23,1,'0',7),(24,2,NULL,NULL,2,'2022-11-28T17:00:00.000Z','',4,24,2,'0',6),(25,3,NULL,NULL,1,'2022-11-28T17:00:00.000Z','',4,25,3,'3',6),(26,1,NULL,NULL,1,'2022-11-28T17:00:00.000Z','',4,26,4,'3',6),(27,1,NULL,NULL,2,'2022-11-29T17:00:00.000Z','',4,27,1,'2',6),(28,1,NULL,NULL,1,'2022-11-29T17:00:00.000Z','',4,28,2,'1',6),(29,1,NULL,NULL,1,'2022-11-27T17:00:00.000Z','',4,29,1,'0',6),(30,1,NULL,NULL,1,'2022-11-28T17:00:00.000Z','',4,30,2,'0',6),(31,2,NULL,NULL,1,'2022-11-28T17:00:00.000Z','',4,31,1,'0',7),(32,1,NULL,NULL,2,'2022-11-28T17:00:00.000Z','',4,32,2,'3',6),(33,2,NULL,NULL,1,'2022-11-28T17:00:00.000Z','',4,33,1,'1',7),(34,3,NULL,1,1,'2022-11-29T17:00:00.000Z','',4,NULL,1,'1',7),(35,1,NULL,2,1,'2022-11-29T17:00:00.000Z','',4,NULL,3,'1',6),(36,1,NULL,NULL,1,'2022-11-29T17:00:00.000Z','',4,34,4,'1',6),(37,1,NULL,NULL,1,'2022-11-30T00:00:00.000Z','',4,35,5,'3',6),(38,1,NULL,3,1,'2022-12-01T00:00:00.000Z','',4,NULL,1,'3',6),(39,1,22,NULL,1,'2022-12-01T00:00:00.000Z','',4,NULL,2,'3',6),(40,1,22,NULL,1,'2022-12-02T00:00:00.000Z','',4,NULL,2,'3',6),(41,1,22,NULL,1,'2022-12-02T00:00:00.000Z','',4,NULL,3,'3',6),(42,1,NULL,4,2,'2022-12-01T00:00:00.000Z','',4,NULL,4,'3',6),(43,3,22,NULL,1,'2022-12-02T00:00:00.000Z','',4,NULL,3,'3',8),(44,2,NULL,5,2,'2022-12-02T00:00:00.000Z','',4,NULL,4,'0',6),(45,3,NULL,6,2,'2022-12-02T00:00:00.000Z','',4,NULL,4,'1',6),(46,1,NULL,7,10,'2022-12-13T00:00:00.000Z','',4,NULL,2,'3',7),(47,3,24,NULL,10,'2022-12-13T00:00:00.000Z','',4,NULL,4,'3',7),(48,2,24,NULL,10,'2022-12-13T00:00:00.000Z','',4,NULL,3,'3',7),(49,3,24,NULL,10,'2022-12-13T00:00:00.000Z','',4,NULL,3,'3',9),(50,2,24,NULL,10,'2022-12-13T00:00:00.000Z','',4,NULL,1,'3',8),(51,3,NULL,8,10,'2022-12-13T00:00:00.000Z','',4,NULL,2,'1',8);
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule_bill_mapping`
--

DROP TABLE IF EXISTS `schedule_bill_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule_bill_mapping` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `id_bill` bigint DEFAULT NULL,
  `id_schedule` bigint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule_bill_mapping`
--

LOCK TABLES `schedule_bill_mapping` WRITE;
/*!40000 ALTER TABLE `schedule_bill_mapping` DISABLE KEYS */;
INSERT INTO `schedule_bill_mapping` VALUES (20,20,22),(21,21,24),(22,22,27),(23,23,29),(24,24,25),(25,25,23),(26,26,26),(27,27,32),(28,28,37),(29,29,38),(30,30,42),(31,31,46);
/*!40000 ALTER TABLE `schedule_bill_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule_branch_mapping`
--

DROP TABLE IF EXISTS `schedule_branch_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule_branch_mapping` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `id_branch` bigint DEFAULT NULL,
  `id_schedule` bigint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule_branch_mapping`
--

LOCK TABLES `schedule_branch_mapping` WRITE;
/*!40000 ALTER TABLE `schedule_branch_mapping` DISABLE KEYS */;
INSERT INTO `schedule_branch_mapping` VALUES (20,1,22),(21,1,23),(22,1,24),(23,1,25),(24,1,26),(25,1,27),(26,1,28),(27,1,29),(28,1,30),(29,1,31),(30,1,32),(31,1,33),(32,1,34),(33,1,35),(34,1,36),(35,1,37),(36,1,38),(37,1,39),(38,1,40),(39,1,41),(40,1,42),(41,1,43),(42,1,44),(43,1,45),(44,1,46),(45,1,47),(46,1,48),(47,1,49),(48,1,50),(49,1,51);
/*!40000 ALTER TABLE `schedule_branch_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service`
--

DROP TABLE IF EXISTS `service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `discount_end` varchar(255) DEFAULT NULL,
  `discount_percent` double DEFAULT NULL,
  `discount_start` varchar(255) DEFAULT NULL,
  `duration` bigint DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service`
--

LOCK TABLES `service` WRITE;
/*!40000 ALTER TABLE `service` DISABLE KEYS */;
INSERT INTO `service` VALUES (1,'nặn mụn','2022-12-17T17:00:00.000Z',2,'2022-12-15T17:00:00.000Z',90,'sua_rua_mat_e100_con_bo.jpg','Nặn mụn',1000000),(2,'xông hơi',NULL,NULL,NULL,60,'sua_rua_mat_e100_con_bo.jpg','Xông hơi',200000),(3,' Với công nghệ máy móc tân tiến cùng kết hợp với hóa mỹ phẩm giúp các chị em nhanh chóng lấy lại sự tươi trẻ của làn da. Việc điều trị nám,',NULL,NULL,NULL,60,'sua_rua_mat_e100_con_bo.jpg',' Dịch vụ trị nám, tàn nhang',400000),(4,'Massage là hình thức thư giãn làm giải tỏa những căng thẳng, mệt mỏi. Kỹ thuật xoa bóp bấm huyệt đã có từ rất lâu và đem lại hiệu quả cao đến tinh thần và làn da.',NULL,NULL,NULL,30,'sua_rua_mat_e100_con_bo.jpg','Dịch vụ massage',300000),(5,'Giúp chị em phụ nữ bảo vệ tóc khỏi các tác động từ môi trường, giúp phục hồi, giữ gìn mái tóc khỏe mạnh, mềm mượt',NULL,NULL,NULL,30,'sua_rua_mat_e100_con_bo.jpg','Dịch Vụ Phục Hồi Tóc Hư Tổn',100000),(6,'Liệu trình chăm sóc da thường xuyên 1 tuần / lần để cung cấp thêm dưỡng chất thấm sâu vào da, nuôi dưỡng làn da sáng mịn.',NULL,NULL,NULL,30,'sua_rua_mat_e100_con_bo.jpg','Dịch vụ chăm sóc da mặt, thư giãn',200000),(7,'',NULL,NULL,NULL,30,NULL,'Tẩy tế bảo chết',100000),(8,'Dịch vụ phun xăm thẩm mỹ sẽ bao gồm môi, mày và mí mắt. Đây là phương pháp phổ biến giúp chị em khắc phục được những khuyết điểm trên khuôn mặt.',NULL,NULL,NULL,90,NULL,'Dịch vụ phun xăm thẩm mỹ',1000000),(9,'',NULL,NULL,NULL,30,NULL,'Dịch vụ Đắp mặt nạ dưỡng da',150000),(10,'',NULL,NULL,NULL,60,NULL,'Dịch vụ Chăm sóc da mặt Thal’ion',500000),(11,'',NULL,NULL,NULL,60,NULL,'Dịch vụ Thủy trị liệu đa chức năng',500000);
/*!40000 ALTER TABLE `service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_brand_mapping`
--

DROP TABLE IF EXISTS `service_brand_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_brand_mapping` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `branch_id` bigint NOT NULL,
  `service_id` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_brand_mapping`
--

LOCK TABLES `service_brand_mapping` WRITE;
/*!40000 ALTER TABLE `service_brand_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_brand_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_product_mapping`
--

DROP TABLE IF EXISTS `service_product_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_product_mapping` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_usage` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  `service_id` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_product_mapping`
--

LOCK TABLES `service_product_mapping` WRITE;
/*!40000 ALTER TABLE `service_product_mapping` DISABLE KEYS */;
INSERT INTO `service_product_mapping` VALUES (2,10,2,2),(3,10,3,2),(4,1,10,3),(5,1,8,4),(6,100,9,5),(8,2,5,6),(9,1,4,6),(10,1,8,6),(11,2,1,7),(12,1,4,8),(13,1,10,8),(14,1,3,9),(16,1,2,11),(17,1,1,10),(19,1,1,1),(20,3,5,1);
/*!40000 ALTER TABLE `service_product_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slot`
--

DROP TABLE IF EXISTS `slot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `slot` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `timeline` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slot`
--

LOCK TABLES `slot` WRITE;
/*!40000 ALTER TABLE `slot` DISABLE KEYS */;
INSERT INTO `slot` VALUES (1,'Chỗ 1','9:00-10:30'),(2,'Chỗ 2','10:30-12:00'),(3,'Chỗ 3','13:00-14:30'),(4,'Chỗ 4','14:30-16:00'),(5,'Chỗ 5','16:00-17:30'),(6,'Chỗ 1','9:00-10:30'),(7,'Chỗ 2','10:30-12:00'),(8,'Chỗ 3','13:00-14:30'),(9,'Chỗ 4','14:30-16:00'),(10,'Chỗ 5','16:00-17:30'),(11,'Chỗ 1','9:00-10:30'),(12,'Chỗ 2','10:30-12:00'),(13,'Chỗ 3','13:00-14:30'),(14,'Chỗ 4','14:30-16:00'),(15,'Chỗ 5','16:00-17:30');
/*!40000 ALTER TABLE `slot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slot_branch_mapping`
--

DROP TABLE IF EXISTS `slot_branch_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `slot_branch_mapping` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `id_branch` bigint DEFAULT NULL,
  `id_slot` bigint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slot_branch_mapping`
--

LOCK TABLES `slot_branch_mapping` WRITE;
/*!40000 ALTER TABLE `slot_branch_mapping` DISABLE KEYS */;
INSERT INTO `slot_branch_mapping` VALUES (1,1,1),(2,1,2),(3,1,3),(4,1,4),(5,1,5),(11,2,6),(12,2,7),(13,2,8),(14,2,9),(15,2,10);
/*!40000 ALTER TABLE `slot_branch_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spa_bed`
--

DROP TABLE IF EXISTS `spa_bed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `spa_bed` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spa_bed`
--

LOCK TABLES `spa_bed` WRITE;
/*!40000 ALTER TABLE `spa_bed` DISABLE KEYS */;
INSERT INTO `spa_bed` VALUES (1,'Giường 1',NULL),(2,'Giường  2',NULL),(3,'Giường  3',NULL),(4,'Giường  4',NULL),(5,'Giường 5',NULL);
/*!40000 ALTER TABLE `spa_bed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `tax_code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
INSERT INTO `supplier` VALUES (1,'Khu Hồ Tây, Đại Mạch, Đông Anh, Hà Nội','Công ty Thiết bị thẩm mỹ Thanh Vân không chỉ là đơn vị cung cấp máy móc, thiết bị, sản phẩm thẩm mỹ công nghệ cao uy tín. ','thietbithanhvan@gmail.com','Công ty thiết bị thẩm mỹ Thanh vân','0907381568','0298493784'),(2,'102 Đường số 3, P. Bình Hưng Hòa, Quận Bình Tân, Tp.Hồ Chí Minh',' iFree chuyên cung cấp các dòng mỹ phẩm theo yêu cầu. Gia công mỹ phẩm độc quyền cho các spa, thẩm mỹ viện. Với nguồn nguyên liệu nhập ngoại xuất xứ rõ ràng. ','contact@ifree.vn','Công Ty TNHH Ifree Việt Nam','0942002020','0912792335'),(3,'63 Thủ Lệ, P. Ngọc Khánh, Quận Ba Đình, TP. Hà Nội','Dermafirm là công ty về dược mỹ phẩm Spa – Thẩm mỹ viện số một tại Hàn Quốc. Với quy trình sản xuất và điều chế từ công nghệ, công thức độc quyền, đạt nhiều chỉ tiêu khắc khe nhất.','labodermafirmvn@gmail.com','Công Ty Dược Mỹ Phẩm Dermafirm Việt Nam','0989388668','0855503545'),(4,'Số 10 ngõ 281 Phương Mai, P. Kim Liên, Quận Đống Đa, TP. Hà Nội',' Với những giá trị cam kết cùng với chất lượng, độ an toàn cao. Cùng kinh nghiệm gần 40 năm hoạt động tại hơn 50 quốc gia trên thế giới.','myphamdrbelter@gmail.com','Công ty TNHH Thương Mại Vạn Minh','0903223644','9036731967'),(5,'N3-X1, 17 Hoàng Ngọc Phách, Phường Láng Hạ, Quận Đống Đa, Tp.Hà Nội','Đại Cát Á là nhà phân phối độc quyền nhiều thương hiệu mỹ phẩm cao cấp từ Hàn và Đức như: JEAN D’ARCEL, BIOCYTE, IASO,…  tại Việt Nam','sales@daicata.com','Công ty TNHH Quốc tế Đại Cát Á','0981398098','0945233176'),(6,'Biệt Thự V10-A04, The Terra An Hưng, Phường La Khê, Quận Hà Đông, Thành Phố Hà Nội, Việt Nam.','Mỹ phẩm','lbvvn@gmail.com','     Công Ty TNHH Ibv Việt Nam','0345345345','4533423423'),(7,'Số 38, Liền Kề 3, Kđt Đại Thanh, Tả Thanh Oai, Thanh Trì, Hà Nội','Mỹ phẩm','khanglinhmp@gmail.com','Công Ty Cổ Phần Dược Mỹ Phẩm Khang Linh','0342434234','3243244342'),(8,'62 Phan Đình Giót, Phương Liệt, Thanh Xuân, Hà Nội','Mỹ phẩm','koji@gmail.com','Công Ty Cổ Phần Dược Koji','0342323442','1254524344'),(9,'Số 21A, Lô 1 Kđt Đền Lừ 1, Hoàng Văn Thụ, Hoàng Mai, Hà Nội','Mỹ phẩm','lafon@gmail.com','Công Ty Cổ Phần Dược Phẩm Lafon Việt Nam','0324323123','3235454435'),(10,'Tầng 1 Ngõ 2/ 277 Vũ Tông Phan, Khương Trung,thanh Xuân, Hà Nội','Mỹ phẩm','beautyqueen@gmail.com',' Công Ty TNHH Thương Mại Đầu Tư Beauty Queen','0353677777','3234234423'),(11,'98C Chiến Thắng','Mỹ phẩm','rejuvanskin@gmail.com','Công Ty TNHH Rejuvaskin Việt Nam','0943533333','3424234342');
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_branch_mapping`
--

DROP TABLE IF EXISTS `user_branch_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_branch_mapping` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `id_branch` bigint NOT NULL,
  `id_user` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_branch_mapping`
--

LOCK TABLES `user_branch_mapping` WRITE;
/*!40000 ALTER TABLE `user_branch_mapping` DISABLE KEYS */;
INSERT INTO `user_branch_mapping` VALUES (1,1,2),(2,2,3),(3,1,4),(4,1,5),(5,1,6),(6,1,7),(7,1,8),(8,1,9),(9,1,10),(10,3,11),(11,5,19),(12,6,12),(13,7,13),(14,8,14),(15,9,16),(16,10,15),(17,11,17),(18,12,18),(19,1,21),(20,1,22),(21,1,23),(22,1,24),(23,13,20),(24,1,26),(25,11,27),(26,2,28),(27,2,29);
/*!40000 ALTER TABLE `user_branch_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_role` (
  `user_id` bigint NOT NULL,
  `role_id` bigint NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `FKa68196081fvovjhkek5m97n3y` (`role_id`),
  CONSTRAINT `FKa68196081fvovjhkek5m97n3y` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`),
  CONSTRAINT `FKj345gk1bovqvfame88rcx7yyx` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_role`
--

LOCK TABLES `user_role` WRITE;
/*!40000 ALTER TABLE `user_role` DISABLE KEYS */;
INSERT INTO `user_role` VALUES (1,1),(2,2),(3,2),(11,2),(12,2),(13,2),(14,2),(15,2),(16,2),(17,2),(18,2),(19,2),(20,2),(25,2),(4,3),(5,3),(21,3),(26,3),(27,3),(28,3),(6,4),(7,4),(8,4),(9,4),(10,4),(22,4),(23,4),(24,4),(29,4);
/*!40000 ALTER TABLE `user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_slot_mapping`
--

DROP TABLE IF EXISTS `user_slot_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_slot_mapping` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `id_slot` bigint DEFAULT NULL,
  `id_user` bigint DEFAULT NULL,
  `id_schedule` bigint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_slot_mapping`
--

LOCK TABLES `user_slot_mapping` WRITE;
/*!40000 ALTER TABLE `user_slot_mapping` DISABLE KEYS */;
INSERT INTO `user_slot_mapping` VALUES (22,'2022-11-28T17:00:00.000Z',1,6,22),(25,'2022-11-28T17:00:00.000Z',3,6,25),(26,'2022-11-28T17:00:00.000Z',4,6,26),(27,'2022-11-29T17:00:00.000Z',1,6,27),(28,'2022-11-29T17:00:00.000Z',2,6,28),(29,'2022-11-27T17:00:00.000Z',1,6,29),(32,'2022-11-28T17:00:00.000Z',2,6,32),(33,'2022-11-28T17:00:00.000Z',1,7,33),(34,'2022-11-29T17:00:00.000Z',1,7,34),(35,'2022-11-29T17:00:00.000Z',3,6,35),(36,'2022-11-29T17:00:00.000Z',4,6,36),(37,'2022-11-30T00:00:00.000Z',5,6,37),(38,'2022-12-01T00:00:00.000Z',1,6,38),(39,'2022-12-01T00:00:00.000Z',2,6,39),(40,'2022-12-02T00:00:00.000Z',2,6,40),(41,'2022-12-02T00:00:00.000Z',3,6,41),(42,'2022-12-01T00:00:00.000Z',4,6,42),(43,'2022-12-02T00:00:00.000Z',3,8,43),(45,'2022-12-02T00:00:00.000Z',4,6,45),(46,'2022-12-13T00:00:00.000Z',2,7,46),(47,'2022-12-13T00:00:00.000Z',4,7,47),(48,'2022-12-13T00:00:00.000Z',3,7,48),(49,'2022-12-13T00:00:00.000Z',3,9,49),(50,'2022-12-13T00:00:00.000Z',1,8,50),(51,'2022-12-13T00:00:00.000Z',2,8,51);
/*!40000 ALTER TABLE `user_slot_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `date_of_birth` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `url_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin',NULL,'admin@sys.com','male','admin','$2a$10$uKdgX6p1UwWNHHwF.1CXBeEiqdf3nDXYZGvsuS3g5QQUj5IAGbvEO','0123456789','sua_rua_mat_e100_con_bo.jpg'),(2,'Ha Noi','2000-04-10T17:00:00.000Z','manager1@sys.com','male','manage1','$2a$10$zhyG8GBm1n0QDj8B9TbLauRW9azsxwJtqb7dAOK0QdVQzW2IeScZm','0284934785','sua_rua_mat_e100_con_bo.jpg'),(3,'Hai Phong','2000-05-17T17:00:00.000Z','manager2@sys.com','female','manager2','$2a$10$xMO6DqhRiYywkgexjhrKxuS.Sh6oQitHmafseIpHBV0awRMHXWqD.','0913227438','sua_rua_mat_e100_con_bo.jpg'),(4,'Ha Noii','2000-02-09T17:00:00.000Z','salestaff11@sys.com','male','salestaff13','$2a$10$RKITara4yBtPdbcQQd8qA.3vp6xTbANToAopEiD20uttEH38FuDnu','0913923872','sua_rua_mat_e100_con_bo.jpg'),(5,'Ha Noi','2000-03-03T17:00:00.000Z','salestaff2@sys.com','female','salestaff2','$2a$10$A0fZECltLaTjhcqPTapWseoludoMZPeVkjbClw70.9B2NZ8G1yVLW','0294973874','sua_rua_mat_e100_con_bo.jpg'),(6,'abc','1999-02-03T17:00:00.000Z','techstaff1@sys.com','female','techstaff1','$2a$10$.DLLk.4gyvuHS88UKuE4bu1jo/QmVCqsFjuOcN7VSxQ2Hpcs.Rtyy','0928473284','sua_rua_mat_e100_con_bo.jpg'),(7,'abc','2000-05-17T17:00:00.000Z','techstaff2@sys.com','female','techtaff2','$2a$10$m.WSGlV.w2o5Ji5BELSdKupsvLDtjpitqWweqsm1EM81Fydq2lS7i','0132984789','sua_rua_mat_e100_con_bo.jpg'),(8,'ha noi','1999-02-12T17:00:00.000Z','techstaff3@sys.com','female','techstaff3','$2a$10$qrzvGzlAP3v0/ULge0EyY.FMGGQe7kZhyvUrOHZC08tvoVJyril8q','0193849378','sua_rua_mat_e100_con_bo.jpg'),(9,'ha noi','2001-06-25T17:00:00.000Z','techstaff4@sys.com','female','techstaff4','$2a$10$H3wQdT6UPEY4QXOELQMsXeto7JtNPB10mp7Xl90OGOXIz9NdGZ1Kq','0913726456','sua_rua_mat_e100_con_bo.jpg'),(10,'ha noi','2003-02-19T17:00:00.000Z','techstaff5@sys.com','female','techstaff5','$2a$10$OymMheniaZ57mV/85XEFoutJwxGC.dJFoziWyMI/stavo3uYKjK2a','0949732647','sua_rua_mat_e100_con_bo.jpg'),(11,'Hà Nội','2000-02-09T17:00:00.000Z','thuvta1@gmail.com','female','Vũ Thị Anh Thư','$2a$10$4RtKVlt.IQLCASzl1MKQJOdxBJ1WbhDM7S1mwrndobDungDuLGDyq','0344242342','sua_rua_mat_e100_con_bo.jpg'),(12,'Hà Nội','2004-05-11T17:00:00.000Z','thutt@gmail.com','female','Trần Thị Thu','$2a$10$uPRBX5DPeoSjvujnGhlGvuhh52TQlzT0jTGcFWMXAB3yU6zuU1PdS','0324342434','sua_rua_mat_e100_con_bo.jpg'),(13,'Trung Hòa, Cầu Giấy, Hà Nội','2000-05-08T17:00:00.000Z','huonglt@gmail.com','female','Lê Thị Hương','$2a$10$fnJtofjpwx9.39bTfeCWS.nwLdJ8wACXGwa00gvQkTb0FLenyaeyO','0324342423','sua_rua_mat_e100_con_bo.jpg'),(14,'Lê Văn Lương, Cầu Giấy, Hà Nội','2000-05-10T17:00:00.000Z','nhily@gmail.com','female','Lê Yến Nhi','$2a$10$aEX6J/EKAJ8nffuXcYNJVOjWdCaAlav36KYx/hkfBTrQnBsDfCU7e','0234324242','sua_rua_mat_e100_con_bo.jpg'),(15,'Lê Văn Lương, Cầu Giấy, Hà Nội','1998-04-08T17:00:00.000Z','nhunght@gmail.com','female','Hoàng Thị Nhung','$2a$10$IfeWUTQOHjrbka9fAzkm1eUvLIPyo.uIy1l2culbpkGvyRPeSwhPm','0324343423','sua_rua_mat_e100_con_bo.jpg'),(16,'Trần Duy Hưng, Cầu Giấy, Hà Nội','1997-05-12T17:00:00.000Z','ngocnb@gmail.com','female','Nguyễn Bích Ngọc','$2a$10$LOy99l/AgF3bG54GVVVTd.ysv1YU/toDAb8HP8nXeMgbSRqPvbBoe','0343242343','sua_rua_mat_e100_con_bo.jpg'),(17,'Triều Khúc, Thanh Trì, Hà Nội','2000-05-07T17:00:00.000Z','anhptl@gmail.com','female','Phạm Thị Lan Anh','$2a$10$6VPZD9kA9T8ECAHHq0GA1erzCOaBXOVFxX7pxz4W5fzO4PyouB0Ta','0434242342','sua_rua_mat_e100_con_bo.jpg'),(18,'Hai Bà Trưng, Hà Nội','2003-04-07T17:00:00.000Z','trangnt@gmail.com','female','Nguyễn Thị Trang','$2a$10$f.RgAaskfN3XcBsukqW//uhbq9BOZIoIg/bAl47u2kjBxqq8gLsxq','0342342342','sua_rua_mat_e100_con_bo.jpg'),(19,'Hai Bà Trưng, Hà Nội','2000-05-10T17:00:00.000Z','trangnt1@gmail.com','female','Nguyễn Thị Trang','$2a$10$GmOzLquN.FxI7kBEYYCqsOaMKVAIr9O4ZkJLJxqqcny7YZCOsDcDS','0343444324','sua_rua_mat_e100_con_bo.jpg'),(20,'Lê Văn Lương, Cầu Giấy, Hà Nội','2000-05-10T17:00:00.000Z','anhnn@gmail.com','female','Nguyễn Ngọc Anh','$2a$10$SU/WT2iUrBYVccEjGU6z9euD1W4Pwx15NNqe9lDvGYUcVGYHC4tla','0132434234','sua_rua_mat_e100_con_bo.jpg'),(21,'Hà Nội','1994-05-03T17:00:00.000Z','tribm@gmail.com','male','Bùi Minh Trí','$2a$10$Asx984Jc8PlAALTfW.eSs.6T7k3TjH8ly9G93EtH0.BGSH8.8qwA6','0343224343','sua_rua_mat_e100_con_bo.jpg'),(22,'Hà Nội','2000-05-04T17:00:00.000Z','nhancm@gmail.com','male','Cao Mỹ Nhân','$2a$10$RBiAvecBL5WTDQMRojenn.XHXGogBf2UJ.bJe2FIYQ1n9ODuFpzry','0343242342','sua_rua_mat_e100_con_bo.jpg'),(23,'123456','2000-03-30T17:00:00.000Z','nghiabt@gmail.com','male','Bùi Trung Nghĩa','$2a$10$qnjFKhKEZKDHb1eWtZBBGOLatZjGwEgmRiNDWIYYKevdBuYs5mpee','0233443424','sua_rua_mat_e100_con_bo.jpg'),(24,'Hà Nội','2000-01-31T17:00:00.000Z','s@gmai.com','female','Dương Thị Mai','$2a$10$WpycTJdSe/WZW5eJdCKHq.sG/zLOaERT8YlAqMlFCVA9bDK/NSPhO','0342423434','sua_rua_mat_e100_con_bo.jpg'),(25,'Hà Nộii','2000-05-07T17:00:00.000Z','dungttt@gmail.com','male','Trần Thị Dung','$2a$10$pO.oY/W8wpnWe7uKNZyhRON/opVnl4MYAiOIhH9g89Xskh9e51rim','0334234324','sua_rua_mat_e100_con_bo.jpg'),(26,'rtrtrtr','1999-02-10T17:00:00.000Z','dungtt@gmail.com','male','    a','$2a$10$e2gvV9x6/0il/ABiAW4SFuKprYrKRDB8mj3pCbWnFgStxHlEOoCGq','0324342342',NULL),(27,'Hà Nội','1999-12-27T17:00:00.000Z','sale2@gmail.com','male','adf','$2a$10$RPfc9lBONThH37h/vdynu.CxLMIz1EaOmad.4XF42co9v1v8DGLgu','0342343434',NULL),(28,'Hà Nội','1998-05-06T17:00:00.000Z','phonglm@gmail.com','male','Lê Minh Phong','$2a$10$M2JuL6Qftezt8zEughicduR0/E198Ysh0/KKvgwYaGuq80TMAYqzG','0342534234',NULL),(29,'Huế','2000-08-16T17:00:00.000Z','congtt@sys.com','male','Trương Thế Công','$2a$10$tycgmekHOP7Err6rJloHFOx2h9a7Gvsf8oHb3w3vP40ke9GL1coNW','0461651123',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-19 14:52:50
